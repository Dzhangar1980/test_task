<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="_token" content="<?php echo csrf_token(); ?>">
        <title>Test</title>
        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <div class="content">
                <div class="title m-b-md">
                    <a href="../">Test task </a>
                </div>
                <br/>
                <div>
                    <h3 id="title"><?php echo e($category->title); ?></h3>
                    <div id="goods">
                        <?php $__currentLoopData = $goods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $good): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <div id="good<?php echo e($good->id); ?>">
                            <h4><?php echo e($good->title); ?></h4>
                            <p>
                                <?php $__currentLoopData = $good->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <a href="<?php echo e($category->alias); ?>"><?php echo e($category->title); ?></a> | 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </p>
                            <img src="<?php echo e($good->image); ?>" height="100px" align ='left'>
                            <p><?php echo e($good->description); ?></p>
                            <p>дата первой продажи товара <?php echo e(date('d.m.Y г. H:i:s ч.', strtotime($good->first_invoice))); ?></p>
                            <p><a href="<?php echo e($good->url); ?>" target="_blank">ссылка на товар на markethot.ru</a></p>
                            <p>Цена <?php echo e($good->price); ?></p>
                            
                            <p>Вариаций <?php echo e($good->amount); ?></p>                         
                            <div id="good_offers<?php echo e($good->id); ?>">
                                <table style="width: 100%; border: 1px;">
                                <tr>
                                    <td>id</td>
                                    <td>article</td>
                                    <td>price</td>
                                    <td>sales</td>
                                    <td>amount</td>
                                </tr>
                                <?php $__currentLoopData = $good->offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <tr>
                                    <td><?php echo e($offer->id); ?></td>
                                    <td><?php echo e($offer->article); ?></td>
                                    <td><?php echo e($offer->price); ?></td>
                                    <td><?php echo e($offer->sales); ?></td>
                                    <td><?php echo e($offer->amount); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </table>
                            </div>
                        </div>
                        <hr/>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        
                    </div>
                </div>
                
            </div>
        </div>
    </body>
    <script>
        $( document ).ready(function() {
            
        });
    </script>
</html>
