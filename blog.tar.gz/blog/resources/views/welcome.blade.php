<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="_token" content="{!! csrf_token() !!}">
        <title>Test</title>
        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <div class="content">
                <div class="title m-b-md">
                    Test task 
                    <button class="btn btn-info" id="update_db">
                        Update DB
                    </button>
                </div>
                <hr/>
                <div>
                    <h3>Categories</h3>
                    @foreach($categories as $category)
                    <a href="category/{{ $category->alias }}">{{ $category->title }}</a> | 
                    @endforeach
                </div>
                <hr/>
                <div>
                    <div id="search">
                        <form action="search" method="get" class="form-control">
                            {{ csrf_field() }}
                            <label>Search: </label>
                            <input type="text" name="good_title" id="good_title" placeholder="Good's title">
                            <input type="text" name="good_desc" id="good_desc" placeholder="Good's description">
                            <input type="submit" value="find">
                        </form>
                    </div>
                    <hr/>
                    <h3>20 best sellers</h3>
                    <div id="goods">
                        @foreach($goods as $good)
                        <div id="good{{ $good->id }}">
                            <h4>{{ $good->title }}</h4>
                            <p>
                                @foreach($good->categories as $category)
                                <a href="category/{{ $category->alias }}">{{ $category->title }}</a> | 
                                @endforeach
                            </p>
                            <img src="{{ $good->image }}" height="100px" align ='left'>
                            <p>{{ $good->description }}</p>
                            <p>дата первой продажи товара {{ date('d.m.Y г. H:i:s ч.', strtotime($good->first_invoice)) }}</p>
                            <p><a href="{{ $good->url }}" target="_blank">ссылка на товар на markethot.ru</a></p>
                            <p>Цена {{ $good->price }}</p>
                            
                            <p>Вариаций {{ $good->amount }}</p>                         
                            <div id="good_offers{{ $good->id }}">
                                <table style="width: 100%; border: 1px;">
                                <tr>
                                    <td>id</td>
                                    <td>article</td>
                                    <td>price</td>
                                    <td>sales</td>
                                    <td>amount</td>
                                </tr>
                                @foreach($good->offers as $offer)
                                <tr>
                                    <td>{{ $offer->id }}</td>
                                    <td>{{ $offer->article }}</td>
                                    <td>{{ $offer->price }}</td>
                                    <td>{{ $offer->sales }}</td>
                                    <td>{{ $offer->amount }}</td>
                                </tr>
                                @endforeach
                                </table>
                            </div>
                        </div>
                        <hr/>
                        @endforeach
                        
                    </div>
                </div>
                
            </div>
        </div>
    </body>
    <script>
        $( document ).ready(function() {
            
        });

        $('#update_db').click(function(e){
            console.log('DB updating begin...');
            //e.preventDefault();
            $('#update_db').text('DB updating begin...');
            $('#update_db').attr('disabled', 'disabled');
            
            var token  = $('meta[name=_token]').attr('content');
            $.ajaxSetup({ headers: { 'X-CSRF-TOKEN': token }});
            var mydata = {};
            mydata['_token'] = token;           
            mydata['url'] = 'https://markethot.ru/export/bestsp'; 

            $.ajax({
                    method: "POST",
                    url: "update_db",
                    cache: false,
                    data: mydata,
                    dataType: 'json', 
                    success: function (response) {
                        $('#update_db').removeAttr('disabled');
                        $('#update_db').text('DB successfully updated now!');
                        console.log(response);
                    },
                    error: function (data) {
                        console.log('Error:', data);
                    }
            });
        });
    </script>
</html>
