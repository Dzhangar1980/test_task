<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Good;
use App\Category;
use App\Offer;
use Illuminate\Support\Facades\DB;

class MainController extends Controller
{
    public function index(Request $request){
        $goods = Good::whereHas('offers', function ($query) {
            $query->orderBy('sales', 'desc');
        })->limit(20)->get();
        
        $categories = Category::distinct()
                //->where('parent','=', null)
                ->orderBy('title', 'asc')
                ->get();
        
        $categories = $this->unique_multidim_array($categories, 'title');
       
        return view('welcome', compact('goods', 'categories'));
    }
    
    public function search(Request $request){
        $query = Good::query();
        if(trim($request->input('good_title')) !== ''){
            $query = $query->where('title', 'like', '%'.trim($request->input('good_title')).'%');
        }
        if(trim($request->input('good_desc')) !== ''){
            $query = $query->where('description', 'like', '%'.trim($request->input('good_desc')).'%');
        }
        $query = $query->orderBy('title', 'asc');
        $goods = $query->paginate(20);
        
        return view('search', compact('goods'));
    }

    public function category(Request $request, $slug = null){
        if($slug == null){
            echo 'Категория не указана';
        }else{
            $category = Category::distinct()->where('alias','=', trim($slug))->first();
            if($category){
                $goods = Good::whereHas('categories', function ($query) use ($category){
                    $query->where('id', '=', $category->id);
                })->get();
                //var_dump($goods);
                return view('category', compact('category', 'goods'));
            }else{
                echo 'Такой категории нету';
            }
        }
    }

    public function update_db(Request $request){
        $json = json_decode(file_get_contents($request->input('url')), true);
        //cleaning DB...
        if($json){
            DB::statement("SET foreign_key_checks=0");
            Good::truncate();
            Category::truncate();
            Offer::truncate();
            DB::statement("SET foreign_key_checks=1");
        }
        //import new data
        foreach ($json as $items){
        foreach ($items as $item){
            $good = new Good;
            $good->id = $item['id'];
            $good->title = $item['title'];
            $good->image = $item['image'];
            $good->description = $item['description'];
            $good->first_invoice = $item['first_invoice'];
            $good->url = $item['url'];
            $good->price = $item['price'];
            $good->amount = $item['amount'];
            $good->save();
            
            foreach ($item['offers'] as $of){
                $offer = new Offer;
                $offer->id = $of['id'];
                $offer->price = $of['price'];
                $offer->amount = $of['amount'];
                $offer->sales = $of['sales'];
                $offer->article = $of['article'];
                $offer->good_id = $item['id'];
                $offer->save();
            }
                        
            foreach ($item['categories'] as $cat){
                $category = new Category;
                $category->id = $cat['id'];
                $category->title = $cat['title'];
                $category->alias = $cat['alias'];
                $category->parent = $cat['parent'];
                $category->good_id = $item['id'];
                $category->save();
            }
        }
        }
        return response()->json('done');
    }
    
    function unique_multidim_array($array, $key) { 
        $temp_array = array(); 
        $i = 0; 
        $key_array = array(); 

        foreach($array as $val) { 
            if (!in_array($val[$key], $key_array)) { 
                $key_array[$i] = $val[$key]; 
                $temp_array[$i] = $val; 
            } 
            $i++; 
        } 
        return $temp_array; 
    } 
}
