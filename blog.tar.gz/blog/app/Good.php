<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Good extends Model
{
    protected $table = 'goods';
    
    public function offers(){
        return $this->hasMany('App\Offer');
    }
    
    public function categories(){
        return $this->hasMany('App\Category');
    }
}
